package il.ac.tau.cs.sw1.ex8.wordsRank;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class BigramModel {
	public static final int MAX_VOCABULARY_SIZE = 14500;
	public static final String VOC_FILE_SUFFIX = ".voc";
	public static final String COUNTS_FILE_SUFFIX = ".counts";
	public static final String SOME_NUM = "some_num";
	public static final int ELEMENT_NOT_FOUND = -1;
	
	String[] mVocabulary;
	int[][] mBigramCounts;
	
	// DO NOT CHANGE THIS !!! 
	public void initModel(String fileName) throws IOException{
		mVocabulary = buildVocabularyIndex(fileName);
		mBigramCounts = buildCountsArray(fileName, mVocabulary);
		
	}
	
	
	/*
	 * @post: mVocabulary = prev(mVocabulary)
	 * @post: mBigramCounts = prev(mBigramCounts)
	 */
	public String[] buildVocabularyIndex(String fileName) throws IOException{ // Q 1  
		String[] vocabArr=new String[MAX_VOCABULARY_SIZE];
		int numOfWords = readLinesAndaddWords(vocabArr,fileName);
		vocabArr= Arrays.copyOf(vocabArr,numOfWords);
		return vocabArr;
	}
	
	private int readLinesAndaddWords (String[] vocabArr, String fileName) throws IOException {
		FileReader f=new FileReader(fileName);
	    BufferedReader buffer=new BufferedReader(f);     
		int numOfWords=0;
		String line;
	    while((line=buffer.readLine()) != null && numOfWords < MAX_VOCABULARY_SIZE)
	    {
	    	numOfWords=addWordsPerLine(vocabArr,line,numOfWords);
	    }
	    buffer.close();
		return numOfWords;
	}


	private int addWordsPerLine(String[] vocabArr, String line, int numOfWords) {
	    String[] curLineArr = line.toLowerCase().split("\\s+");
	      for (String word:curLineArr) {
	    	  word=adjustWord(word);
	    	  if (word !=null && notDuplicate(word,vocabArr)) {
	    		  vocabArr[numOfWords]=word;
	    		  numOfWords++;
	    		  if (numOfWords==MAX_VOCABULARY_SIZE)
	    			  break;
	    	  }
	      }
		return numOfWords;
	}



	private boolean notDuplicate(String adjusted, String[] vocabArr) {
		for (String word:vocabArr) {
			if (word == null)
				break;
			if (word.equals(adjusted))
				return false;
		}
		return true;
	}

	public String adjustWord(String word) {
		if (word.length()==0)
			return null;
		Boolean onlyNumbers=true;
		Boolean atLeastOneEng=false;
		for (int i=0;i <word.length();i++) {
			char cur=word.charAt(i);
			if (!Character.isDigit(cur)) {
				onlyNumbers=false;
				if ('a' <= cur && cur <= 'z') {
					atLeastOneEng=true;
					break;
				}
			}	
		}
		if (onlyNumbers) {
			return SOME_NUM;
		}
		if (atLeastOneEng)
			return word;
		return null;
	}


	/*
	 * @post: mVocabulary = prev(mVocabulary)
	 * @post: mBigramCounts = prev(mBigramCounts)
	 */
	public int[][] buildCountsArray(String fileName, String[] vocabulary) throws IOException{ // Q - 2
		int numOfWords = vocabulary.length;
		int[][] countsArr= new int[numOfWords][numOfWords];
		FileReader f=new FileReader(fileName);
	    BufferedReader buffer=new BufferedReader(f);     
		String line;
	    while((line=buffer.readLine()) != null)
	    {
	    	String[] lineArr = line.toLowerCase().split("\\s+");
	    	countPerLine(lineArr,vocabulary,countsArr);
	    }
	    buffer.close();		
		return countsArr;

	}

	private void countPerLine(String[] line, String[] vocabulary, int[][] countsArr) {
		int i=0;
		int idx1=-1;
		int idx2=-1;
		while (i<line.length-1) {
			if (idx2!=ELEMENT_NOT_FOUND)
				idx1=idx2;
			else
				{
				idx1=getWordIndex(line[i],vocabulary);
				if (idx1==ELEMENT_NOT_FOUND) {
					i++;
					continue;
				}
			}
			idx2=getWordIndex(line[i+1],vocabulary);
			if (idx2 == ELEMENT_NOT_FOUND) {
				i+=2;
				continue;
			}
			countsArr[idx1][idx2]+=1;
			i++;
			
		}
		
	}


	/*
	 * @pre: the method initModel was called (the language model is initialized)
	 * @pre: fileName is a legal file path
	 */
	public void saveModel(String fileName) throws IOException { // Q-3
		FileWriter vocFile;
		vocFile = new FileWriter(fileName+VOC_FILE_SUFFIX);
		BufferedWriter buffer = new BufferedWriter(vocFile);
		writeVocFile(buffer);
		FileWriter countsFile = new FileWriter(fileName +COUNTS_FILE_SUFFIX);
		buffer = new BufferedWriter(countsFile);
		writeCountsFile(buffer);
		buffer.close();
	}
	
	
	private void writeVocFile(BufferedWriter buffer) throws IOException {
		buffer.write(mVocabulary.length+ " words");
		for (int i=0;i<mVocabulary.length;i++) {
			buffer.newLine();
			buffer.write(i+","+mVocabulary[i]);
		}	
		buffer.flush();
	}
	
	private void writeCountsFile(BufferedWriter buffer) throws IOException {
		int numOfWords=mVocabulary.length;
		boolean wrote=false;
		int curCount;
		for (int i=0;i<numOfWords;i++) {
			for (int j=0;j<numOfWords;j++) {
				if ((curCount = mBigramCounts[i][j])!=0) {
					if (wrote)
						buffer.newLine();
					else
						wrote=true;
					buffer.write(i+","+j+":"+curCount);
					
			}
			}
		}
		buffer.flush();
		
	}

	/*
	 * @pre: fileName is a legal file path
	 */
	public void loadModel(String fileName) throws IOException{ // Q - 4
		FileReader file=new FileReader(fileName+VOC_FILE_SUFFIX);
	    BufferedReader buffer=new BufferedReader(file);  
	    String[] line = buffer.readLine().split(" ");
	    int numOfWords=Integer.parseInt(line[0]);
	    String[] vocArr =new String[numOfWords];
	    for (int i=0;i<numOfWords;i++) {
	    	line=buffer.readLine().split(",");
	    	vocArr[i]=line[1];
	    }
	    int[][] countsArr= new int[numOfWords][numOfWords];
	    FileReader countsFile=new FileReader(fileName+COUNTS_FILE_SUFFIX);
	    buffer=new BufferedReader(countsFile);  
	    String lineStr;
	    while ((lineStr = buffer.readLine())!= null) {
	    	line =lineStr.split("[,:]");
	    	int i=Integer.parseInt(line[0]);
	    	int j=Integer.parseInt(line[1]);
	    	int count=Integer.parseInt(line[2]);
	    	countsArr[i][j]=count;
	    	
	    }  
	    buffer.close();
		mVocabulary=vocArr;
		mBigramCounts=countsArr;
	}

	private int getWordIndex(String word,String[] vocabulary){  // Q - 5
		if (word.length() == 0)
			return ELEMENT_NOT_FOUND;
		if (Character.isDigit(word.charAt(0))) {
			if(adjustWord(word)==SOME_NUM)
				word = SOME_NUM;		
		}
		
		for (int i=0;i<vocabulary.length;i++) {
			if (vocabulary[i].equals(word))
				return i;
		}
		return ELEMENT_NOT_FOUND;
	}
	
	/*
	 * @pre: word is in lowercase
	 * @pre: the method initModel was called (the language model is initialized)
	 * @pre: word is in lowercase
	 * @post: $ret = -1 if word is not in vocabulary, otherwise $ret = the index of word in vocabulary
	 */
	public int getWordIndex(String word){  // Q - 5
		return getWordIndex(word,mVocabulary);
	}
	
	
	
	/*
	 * @pre: word1, word2 are in lowercase
	 * @pre: the method initModel was called (the language model is initialized)
	 * @post: $ret = the count for the bigram <word1, word2>. if one of the words does not
	 * exist in the vocabulary, $ret = 0
	 */
	public int getBigramCount(String word1, String word2){ //  Q - 6
		int index1=getWordIndex(word1);
		int index2=getWordIndex(word2);
		if (index1==ELEMENT_NOT_FOUND ||index2==ELEMENT_NOT_FOUND)
			return 0;
		return mBigramCounts[index1][index2];
	}
	
	
	/*
	 * @pre word in lowercase, and is in mVocabulary
	 * @pre: the method initModel was called (the language model is initialized)
	 * @post $ret = the word with the lowest vocabulary index that appears most fequently after word (if a bigram starting with
	 * word was never seen, $ret will be null
	 */
	public String getMostFrequentProceeding(String word){ //  Q - 7
		int wordIndex=getWordIndex(word);
		int maxCount=0;
		int maxIndex=0;
		for (int i=0;i<mVocabulary.length;i++) {
			int cur=mBigramCounts[wordIndex][i];
			if (cur>maxCount) {
				maxIndex=i;
				maxCount=cur;
			}
		}
		if (maxCount==0)
			return null;
		return mVocabulary[maxIndex];
	}
	
	
	/* @pre: sentence is in lowercase
	 * @pre: the method initModel was called (the language model is initialized)
	 * @pre: each two words in the sentence are are separated with a single space
	 * @post: if sentence is is probable, according to the model, $ret = true, else, $ret = false
	 */
	public boolean isLegalSentence(String sentence){  //  Q - 8
		if (sentence == null)
			return true;
		String [] wordsArr=sentence.split(" ");
		if (wordsArr.length==1)
			return (getWordIndex(wordsArr[0])!=ELEMENT_NOT_FOUND);
		for (int i=0;i<wordsArr.length-1;i++) {
			String word1=wordsArr[i];
			String word2=wordsArr[i+1];
			if (getBigramCount(word1,word2)==0)
				return false;
		}
		
		return true;
	}
	
	
	
	/*
	 * @pre: arr1.length = arr2.legnth
	 * post if arr1 or arr2 are only filled with zeros, $ret = -1, otherwise calcluates CosineSim
	 */
	public static double calcCosineSim(int[] arr1, int[] arr2){ //  Q - 9
		int [] zeros= new int[arr1.length];
		if (Arrays.equals(zeros, arr1) || Arrays.equals(zeros, arr2))
			return -1;
		double val=calcVectors(arr1,arr2)/(Math.sqrt(calcVectors(arr1,arr1))*Math.sqrt(calcVectors(arr2,arr2)));
		return val;
	}
	

	
	private static double calcVectors(int[] arr1, int[] arr2) {
		double sum=0;
		for (int i=0;i<arr1.length;i++) {
			sum+=arr1[i]*arr2[i];
		}
		return sum;
	}



	/*
	 * @pre: word is in vocabulary
	 * @pre: the method initModel was called (the language model is initialized), 
	 * @post: $ret = w implies that w is the word with the largest cosineSimilarity(vector for word, vector for w) among all the
	 * other words in vocabulary
	 */
	public String getClosestWord(String word){ //  Q - 10
		double max=0;
		int maxIndex=0;
		int wordIndex=getWordIndex(word);
		int [] wordVector=mBigramCounts[wordIndex];
		for (int i=0;i<mBigramCounts.length;i++) {
			if (i==wordIndex)
				continue;
			double curCosSim=calcCosineSim(wordVector,mBigramCounts[i]);
			if (curCosSim>max) {
				max=curCosSim;
				maxIndex=i;
			}
			
		}
		return mVocabulary[maxIndex];
	}

	/*
	 * @pre: word is a String
	 * @pre: the method initModel was called (the language model is initialized)
	 * @post: $ret = the number of word's occurrences in the text.
	 */
	public int getWordCount(String word){ //  Q - 11
		int wordIndex=getWordIndex(word);
		if (wordIndex==ELEMENT_NOT_FOUND)
			return 0;
		int countWhenBefore=0;
		for (int i:mBigramCounts[wordIndex])
			countWhenBefore+=i;
		int countWhenAfter=0;
		for (int i=0;i<mBigramCounts.length;i++)
			countWhenAfter+=mBigramCounts[i][wordIndex];
		return Math.max(countWhenBefore, countWhenAfter);
	}
	
}
